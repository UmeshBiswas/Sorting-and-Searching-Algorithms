#include<stdio.h>
#include<stdlib.h>
void merge_sort(long int a[],int f,int l);
void Marge(long int a[],int f,int m,int l);
long int a[300000];
int main()
{
     long int a[300000],num;
     scanf("%ld",&num);

    for(int i=0;i<num;i++){
        a[i]=rand()%99999;

    }
    merge_sort(a,0,(num-1));
    for(int i=0;i<(num-1);i++){
    printf("%ld ",a[i]);
    }

}
void merge_sort(long int a[],int f,int l)
{
     int m;
    if(f<l)
    {

        m=(f+l)/2;
        merge_sort(a,f,m);
        merge_sort(a,m+1,l);
        Marge(a,f,m,l);
    }
}
void Marge(long int a[],int f,int m,int l)
{
    int i,j,k,t[l];
    i=f;
    j=m+1;
    k=f;
    while(i<=m&&j<=l)
    {
        if(a[i]<=a[j]){
            t[k]=a[i];
            i++;
        }
        else{
            t[k]=a[j];
            j++;
        }
        k++;
    }
    if(i>m){
        for(int b=j;b<=l;b++){
            t[k]=a[b];
            k++;
        }
    }
    else{
        for(int c=i;c<=m;c++){
            t[k]=a[c];
            k++;
        }
    }
    for( i=f; i<=l; i++)
    {
        a[i] = t[i];
    }
}
