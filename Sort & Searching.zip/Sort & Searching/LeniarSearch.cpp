#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a[100],found;
    for(int i=0;i<10;i++){
        a[i]=rand()%99;

    }
     for(int i=0;i<10;i++){
    printf("%d ",a[i]);
    }
    printf("\n");
    scanf("%d",&found);
    int location;
    for(int i=0;i<10;i++)
    {
        if(a[i]==found){
            location=i;
            printf("Index:%d",location);

            break;
        }
    }



}
