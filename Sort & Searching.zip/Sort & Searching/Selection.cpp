#include<stdio.h>
#include<stdlib.h>
int main()
{
    long long int num;
   scanf("%lld",&num);
   long long int a[200000],small_index;
    for(int i=0;i<num;i++){
        a[i]=rand()%9999;

    }

    for(int j=0;j<(num-1);j++){
        small_index=j;
        for(int k=j+1;k<num;k++){
            if(a[k]<a[small_index]){
                small_index=k;
            }
        }
        int temp=a[j];
        a[j]=a[small_index];
        a[small_index]=temp;

    }
    printf("\n\n");
    for(int j=0;j<num;j++)
    printf("%lld ",a[j]);
}
