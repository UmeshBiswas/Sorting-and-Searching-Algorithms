#include<stdio.h>
#include<stdlib.h>
void merge_sort(int a[],int f,int l);
void Merge(int a[],int f,int m,int l);
int a[100];
int main()
{
    for(int i=0;i<10;i++)
    {
        a[i]=rand()%9999;
    }
    merge_sort(a,0,9);
    for(int i=0;i<9;i++){
        printf("%d ",a[i]);
    }
}
void merge_sort(int a[],int f,int l)
{
    int m;
    if(f<l){
        m=(f+l)/2;
        merge_sort(a,f,m);
        merge_sort(a,m+1,l);
        Merge(a,f,m,l);
    }
}
void Merge(int a[],int f,int m,int l)
{
    int i,j,k,t[l];
    i=f;
    j=m+1;
    k=f;
    while(i<=m && j<=l)
    {
        if(a[i]<=a[j])
        {
            t[k]=a[i];
            i++;
        }
        else
        {
            t[k]=a[j];
            j++;

        }
        k++;
    }
    if(i>m){
        for(int b=j;b<=l;b++){
            t[k]=a[j];
            k++;
        }
    }
     else {
        for(int c=i;c<=m;c++){
            t[k]=a[i];
            k++;
        }
    }
    for(i=f;i<=l;i++){
        a[i]=t[i];
    }



}
