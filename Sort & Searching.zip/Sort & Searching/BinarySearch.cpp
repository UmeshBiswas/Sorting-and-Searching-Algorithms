#include<stdio.h>
#include<stdlib.h>
int main()
{
    int A[5],i,mid,first,last,x;
    for(i=0; i<5; i++)
    {
        scanf("%d",&A[i]);
    }

    first=0;
    last=4;
    scanf("\n%d",&x);

    while(first<=last)
    {
          mid=(first+last)/2;

        if(x==A[mid])
        {
            int target=x;
            printf("%d  %d",target,mid);
            break;
        }
        else if(x<A[mid])
            last=mid-1;
        else
            first=mid+1;


    }
}
