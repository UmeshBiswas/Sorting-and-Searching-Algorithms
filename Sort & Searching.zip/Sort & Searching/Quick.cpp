#include <stdio.h>
#include <stdlib.h>
#include <iostream>
 using namespace std;
 void quick_sort(long int a[], int f, int l);
 int make_part(long int a[], int first, int last);
 long int a[5];
 int main()
 {
     int i,num;
     scanf("%ld",&num);
    for(i=0; i<num; i++)
    {
        a[i] = rand()%9999;

    }
    quick_sort(a, 0,(num-1));
    for(i=0;i<(num-1);i++)
        printf("%ld ", a[i]);
 }

 void quick_sort(long int a[], int f, int l)
 {

     if(f<l)
     {
         int j = make_part(a,f,l+1);
         quick_sort(a,f,j-1);
         quick_sort(a,j+1,l);
     }
 }

 int make_part(long int a[], int first, int last)
 {
     int p_value = a[first];
     int i = first;
     int j = last;
     do
     {
         do
         {
             i++;
         }while(a[i]<=p_value);

         do
         {
             j--;
         }while(a[j]>p_value);

         if(i<j)
         {
             int temp = a[i];
             a[i] = a[j];
             a[j] = temp;
         }

     }while(i<j);

     a[first] = a[j];
     a[j] = p_value;

     return j;

 }
