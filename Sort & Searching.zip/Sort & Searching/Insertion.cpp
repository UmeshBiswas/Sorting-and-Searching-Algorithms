#include<stdio.h>
#include<stdlib.h>
int main()
{
    long long int a[200000],key,num;
    scanf("%lld",&num);
    for(int i=0;i<num;i++){
        a[i]=rand()%9999;

    }

    for( int i=1;i<num;i++){
        key=a[i];
        int j=i-1;
        while(j>=0&&a[j]>key)
        {
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=key;
    }
     printf("\n");
    for(int j=0;j<num;j++)
    printf("%lld ",a[j]);

}
